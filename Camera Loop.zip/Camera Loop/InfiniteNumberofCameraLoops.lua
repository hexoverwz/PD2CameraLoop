-- Infinite Number of Camera 
if inGame() and isPlaying() and not inChat() then
    _toggleInfNumCamLoops = not _toggleInfNumCamLoops
    if not _SecurityCameraInteractionFunction then _SecurityCameraInteractionFunction = SecurityCameraInteractionExt._interact_blocked end
    
    if _toggleInfNumCamLoops then
        managers.chat:_receive_message(1, "Stealth Suite System", "Infinite Number Of Camera Loops ON", tweak_data.system_chat_color)
    else
        managers.chat:_receive_message(1, "Stealth Suite System", "Infinite Number Of Camera Loops OFF", tweak_data.system_chat_color)
    end
    
    function SecurityCameraInteractionExt:_interact_blocked(player)
        if _toggleInfNumCamLoops then
            SecurityCamera.active_tape_loop_unit = false
        else
            return _SecurityCameraInteractionFunction (self, player)
        end
        local camera_loop_duration_multiplier = 60
        local old_start = old_start or SecurityCamera._start_tape_loop
        function SecurityCamera:_start_tape_loop(tape_loop_t)
	        old_start(self, camera_loop_duration_multiplier)
        end
    end
end